$( document ).ready(function() {
	
    $("input").keyup(function(){
	var quantity=$('#quantity').val();
	var price=$('#price').val();
	var result=quantity*price;
	$('#subtotal').val(result);
	
});
});
